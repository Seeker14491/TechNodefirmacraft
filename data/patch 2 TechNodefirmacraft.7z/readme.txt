Instructions:

1. In your MultiMC folder, delete "instances\TechNodefirmacraft\minecraft\mods\betterfoliage-mc1.7.10-2.0.9.jar"
2. Copy the provided "instances" folder to your MultiMC folder. 