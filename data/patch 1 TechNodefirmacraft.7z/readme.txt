Directions

1. In your MultiMC folder, delete "instances\TechNodefirmacraft\minecraft\mods\journeymap-1.7.10-5.1.4-fairplay.jar".
2. From this folder copy "instances" to your MultiMc folder.